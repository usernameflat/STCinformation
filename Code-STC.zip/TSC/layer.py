
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from graphConstruct import get_EdgeAttention, get_NodeAttention, normalize


class HGATLayer(nn.Module):

    def __init__(self, in_features, out_features, dropout, transfer, concat=True, bias=False, edge=True):
        super(HGATLayer, self).__init__()
        self.dropout = dropout
        self.in_features = in_features
        self.out_features = out_features
        self.concat = concat
        self.edge = edge

        self.transfer = transfer

        if self.transfer:
            self.weight = Parameter(torch.Tensor(self.in_features, self.out_features))
        else:
            self.register_parameter('weight', None)

        self.weight2 = Parameter(torch.Tensor(self.in_features, self.out_features))
        self.weight3 = Parameter(torch.Tensor(self.out_features, self.out_features))

        if bias:
            self.bias = Parameter(torch.Tensor(self.out_features))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.out_features)
        if self.weight is not None:
            self.weight.data.uniform_(-stdv, stdv)
        self.weight2.data.uniform_(-stdv, stdv)
        self.weight3.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, x, adj, root_emb):

        if self.transfer:
            x = x.matmul(self.weight)
        else:
            x = x.matmul(self.weight2)

        if self.bias is not None:
            x = x + self.bias

            # n2e_att = get_NodeAttention(x, adj.t(), root_emb)

        adjt = F.softmax(adj.T, dim=1)
        # adj = normalize(adj)

        edge = torch.matmul(adjt, x)

        edge = F.dropout(edge, self.dropout, training=self.training)
        edge = F.relu(edge, inplace=False)

        e1 = edge.matmul(self.weight3)

        adj = F.softmax(adj, dim=1)
        # adj = get_EdgeAttention(adj)

        node = torch.matmul(adj, e1)
        node = F.dropout(node, self.dropout, training=self.training)

        if self.concat:
            node = F.relu(node, inplace=False)

        if self.edge:
            edge = torch.matmul(adjt, node)
            edge = F.dropout(edge, self.dropout, training=self.training)
            edge = F.relu(edge, inplace=False)
            return node, edge
        else:
            return node

    def __repr__(self):
        return self.__class__.__name__ + ' (' + str(self.in_features) + ' -> ' + str(self.out_features) + ')'

class TimeMLP(nn.Module):
    def __init__(self, hidden_dim, out_dim):
        super(TimeMLP, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(1, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, out_dim)
        )

    def forward(self, t):  # t: [num_edges]
        return self.mlp(t.unsqueeze(1))  # [num_edges, out_dim]


class TGATLayer(nn.Module):
    def __init__(self, in_features, out_features, time_hidden_dim=32, n_heads=1, dropout=0.2):
        super(TGATLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.n_heads = n_heads
        self.dropout = dropout

        self.W = nn.Linear(in_features, out_features * n_heads, bias=False)
        self.a = nn.Parameter(torch.empty(n_heads, 2 * out_features))
        self.time_encoder = TimeMLP(hidden_dim=time_hidden_dim, out_dim=out_features * n_heads)
        self.leakyrelu = nn.LeakyReLU(0.2)

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.W.weight)
        nn.init.xavier_uniform_(self.a)
        for m in self.time_encoder.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)

    def forward(self, x, edge_index, edge_time):
        num_nodes = x.size(0)
        edge_src, edge_dst = edge_index  # [num_edges]

        h = self.W(x)  # [num_nodes, out_features * n_heads]

        # ⏱ 连续时间嵌入（MLP）
        t_emb = self.time_encoder(edge_time.float())  # [num_edges, out_features * n_heads]

        # 获取源和目标节点表示 + 时间嵌入
        h_src = h[edge_src] + t_emb
        h_dst = h[edge_dst] + t_emb

        h_src = h_src.view(-1, self.n_heads, self.out_features)
        h_dst = h_dst.view(-1, self.n_heads, self.out_features)

        attn_input = torch.cat([h_src, h_dst], dim=-1)  # [num_edges, n_heads, 2 * out_features]
        attn_scores = (attn_input * self.a).sum(dim=-1)
        attn_scores = self.leakyrelu(attn_scores)
        attn_scores = F.softmax(attn_scores, dim=0)
        attn_scores = F.dropout(attn_scores, self.dropout, training=self.training)

        # 每个头聚合
        out = []
        for head in range(self.n_heads):
            message = h_src[:, head, :] * attn_scores[:, head].unsqueeze(-1)
            out_head = torch.zeros(num_nodes, self.out_features, device=x.device)
            out_head.index_add_(0, edge_dst, message)
            out.append(out_head)

        return torch.cat(out, dim=-1)  # [num_nodes, out_features * n_heads]

