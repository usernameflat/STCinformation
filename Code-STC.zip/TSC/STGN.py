import math
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from layer import TGATLayer
from torch_geometric.nn import GCNConv
import torch.nn.init as init
import Constants
from TransformerBlock1 import TransformerBlock
from torch.autograd import Variable


def get_previous_user_mask(seq, user_size):
    ''' Mask previous activated users.'''
    assert seq.dim() == 2
    prev_shape = (seq.size(0), seq.size(1), seq.size(1))
    seqs = seq.repeat(1, 1, seq.size(1)).view(seq.size(0), seq.size(1), seq.size(1))
    previous_mask = np.tril(np.ones(prev_shape)).astype('float32')
    previous_mask = torch.from_numpy(previous_mask)
    if seq.is_cuda:
        previous_mask = previous_mask.cuda()
    masked_seq = previous_mask * seqs.data.float()

    # force the 0th dimension (PAD) to be masked
    PAD_tmp = torch.zeros(seq.size(0), seq.size(1), 1)
    if seq.is_cuda:
        PAD_tmp = PAD_tmp.cuda()
    masked_seq = torch.cat([masked_seq, PAD_tmp], dim=2)
    ans_tmp = torch.zeros(seq.size(0), seq.size(1), user_size)
    if seq.is_cuda:
        ans_tmp = ans_tmp.cuda()
    masked_seq = ans_tmp.scatter_(2, masked_seq.long(), float(-1000))
    masked_seq = Variable(masked_seq, requires_grad=False)
    # print("masked_seq ",masked_seq.size())
    return masked_seq.cuda()


# Fusion gate
class Fusion(nn.Module):
    def __init__(self, input_size, out=1, dropout=0.2):
        super(Fusion, self).__init__()
        self.linear1 = nn.Linear(input_size, input_size)
        self.linear2 = nn.Linear(input_size, out)
        self.dropout = nn.Dropout(dropout)
        self.init_weights()

    def init_weights(self):
        init.xavier_normal_(self.linear1.weight)
        init.xavier_normal_(self.linear2.weight)

    def forward(self, hidden, dy_emb):
        emb = torch.cat([hidden.unsqueeze(dim=0), dy_emb.unsqueeze(dim=0)], dim=0)
        emb_score = F.softmax(self.linear2(torch.tanh(self.linear1(emb))), dim=0)
        emb_score = self.dropout(emb_score)
        out = torch.sum(emb_score * emb, dim=0)
        return out


'''Learn friendship network'''

class GraphNN(nn.Module):
    def __init__(self, ntoken, ninp, dropout=0.5, is_norm=True):
        super(GraphNN, self).__init__()
        self.embedding = nn.Embedding(ntoken, ninp, padding_idx=0)
        # in:inp,out:nip*2
        self.gnn1 = GCNConv(ninp, ninp * 2)
        self.gnn2 = GCNConv(ninp * 2, ninp)
        self.is_norm = is_norm

        self.dropout = nn.Dropout(dropout)
        if self.is_norm:
            self.batch_norm = torch.nn.BatchNorm1d(ninp)
        self.init_weights()

    def init_weights(self):
        init.xavier_normal_(self.embedding.weight)

    def forward(self, graph):
        graph_edge_index = graph.edge_index.cuda()
        graph_x_embeddings = self.gnn1(self.embedding.weight, graph_edge_index)
        graph_x_embeddings = self.dropout(graph_x_embeddings)
        graph_output = self.gnn2(graph_x_embeddings, graph_edge_index)
        if self.is_norm:
            graph_output = self.batch_norm(graph_output)
        # print(graph_output.shape)
        return graph_output.cuda()


class TGAT(nn.Module):
    def __init__(self, in_dim, out_dim, time_dim, n_heads=1, dropout=0.3, is_norm=True):
        super(TGAT, self).__init__()
        self.dropout = dropout
        self.is_norm = is_norm
        if self.is_norm:
            self.batch_norm1 = nn.BatchNorm1d(out_dim)
        self.tgat1 = TGATLayer(in_dim, out_dim, time_dim, n_heads, dropout)
        self.fus1 = Fusion(out_dim)

    def forward(self, x, edge_index, edge_time):
        node_emb = self.tgat1(x, edge_index, edge_time)
        node_emb = F.dropout(node_emb, self.dropout, training=self.training)
        if self.is_norm:
            node_emb = self.batch_norm1(node_emb)
        return self.fus1(x, node_emb)


class SpatioTemporalConvolution(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size_local=3, kernel_size_global=7):
        super(SpatioTemporalConvolution, self).__init__()

        # 局部卷积层
        self.local_conv = nn.Conv1d(in_channels, out_channels, kernel_size=kernel_size_local,
                                    padding=kernel_size_local // 2)

        # 全局卷积层
        self.global_conv = nn.Conv1d(in_channels, out_channels, kernel_size=kernel_size_global,
                                     padding=kernel_size_global // 2)

    def forward(self, x):
        # x 的形状应该是 (batch_size, in_channels, seq_length)
        local_out = self.local_conv(x)  # (batch_size, out_channels, seq_length)
        global_out = self.global_conv(x)  # (batch_size, out_channels, seq_length)

        # 将局部和全局特征相加
        return local_out + global_out  # (batch_size, out_channels, seq_length)



class STGN(nn.Module):
    def __init__(self, opt, dropout=0.3):
        super(STGN, self).__init__()
        self.hidden_size = opt.d_word_vec
        self.n_node = opt.user_size
        self.pos_dim = 8
        self.dropout = nn.Dropout(dropout)
        self.initial_feature = opt.initialFeatureSize

        # 替换掉 HGNN_ATT
        self.tgat = TGAT(
            in_dim=self.initial_feature,
            out_dim=self.hidden_size,
            time_dim=16,
            n_heads=1,
            dropout=dropout
        )

        self.gnn = GraphNN(self.n_node, self.initial_feature, dropout=dropout)
        self.fus = Fusion(self.hidden_size + self.pos_dim)
        self.fus2 = Fusion(self.hidden_size)
        self.pos_embedding = nn.Embedding(1000, self.pos_dim)
        self.decoder_attention1 = TransformerBlock(input_size=self.hidden_size + self.pos_dim, n_heads=8)
        self.decoder_attention2 = TransformerBlock(input_size=self.hidden_size + self.pos_dim, n_heads=8)

        self.linear2 = nn.Linear(self.hidden_size + self.pos_dim, self.n_node)
        self.embedding = nn.Embedding(self.n_node, self.initial_feature, padding_idx=0)

        self.spatial_temporal_conv = SpatioTemporalConvolution(in_channels=self.hidden_size, out_channels=self.hidden_size)

        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            weight.data.uniform_(-stdv, stdv)

    def forward(self, input, input_timestamp, input_idx, graph, edge_index, edge_time):
        input = input[:, :-1]
        input_timestamp = input_timestamp[:, :-1]

        hidden = self.dropout(self.gnn(graph))  # 初始特征
        tgat_node_emb = self.tgat(hidden, edge_index.cuda(), edge_time.cuda())  # 使用 TGAT 编码节点

        mask = (input == Constants.PAD)
        batch_t = torch.arange(input.size(1)).expand(input.size()).cuda()
        order_embed = self.dropout(self.pos_embedding(batch_t))
        batch_size, max_len = input.size()

        dyemb = F.embedding(input.cuda(), tgat_node_emb)
        dyemb = self.spatial_temporal_conv(dyemb.permute(0, 2, 1))
        dyemb = dyemb.permute(0, 2, 1)

        fri_embed = torch.cat([F.embedding(input.cuda(), hidden.cuda()), order_embed], dim=-1)
        diff_embed = torch.cat([dyemb, order_embed], dim=-1)

        diff_att_out = self.decoder_attention1(diff_embed, diff_embed, diff_embed, mask=mask.cuda())
        fri_att_out = self.decoder_attention2(fri_embed, fri_embed, fri_embed, mask=mask.cuda())

        # diff_att_out = self.dropout(diff_embed)
        # fri_att_out = self.dropout(fri_embed)

        diff_att_out = self.dropout(diff_att_out)
        fri_att_out = self.dropout(fri_att_out)

        att_out = self.fus(diff_att_out, fri_att_out)

        output_u = self.linear2(att_out)
        mask = get_previous_user_mask(input.cpu(), self.n_node)

        return (output_u + mask).view(-1, output_u.size(-1)).cuda()

