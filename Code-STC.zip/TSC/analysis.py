import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.fft import fft, ifft, fftfreq
import os

def parse_cascades(file_path):
    """Parse Twitter or Douban cascades.txt file, handling timestamp and user ID pairs, skipping pairs with trailing commas"""
    cascades = []
    try:
        with open(file_path, 'r') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) < 2:  # Need at least cascade ID and one pair
                    print(f"Warning: Line too short, skipping: {line.strip()}")
                    continue
                try:
                    cascade_id = int(parts[0])
                    nodes = []
                    # Process timestamp,userID pairs
                    for pair in parts[1:]:
                        if ',' in pair and not pair.endswith(','):
                            try:
                                timestamp, user_id = pair.split(',')
                                timestamp = float(timestamp)  # Unix timestamp (seconds)
                                user_id = int(user_id)  # User ID
                                nodes.append((user_id, timestamp))
                            except ValueError:
                                print(f"Warning: Invalid pair '{pair}' in cascade {cascade_id}, full line: {line.strip()}, skipped")
                                continue
                        elif pair.endswith(','):
                            print(f"Warning: Pair with trailing comma '{pair}' in cascade {cascade_id}, full line: {line.strip()}, skipped")
                            continue  # Explicitly skip pairs with trailing comma
                        else:
                            print(f"Warning: Malformed pair '{pair}' in cascade {cascade_id}, full line: {line.strip()}, skipped")
                            continue  # Skip other malformed pairs
                    if nodes:
                        cascades.append({
                            'id': cascade_id,
                            'num_nodes': len(nodes),  # Count valid pairs as nodes
                            'nodes': nodes
                        })
                    else:
                        print(f"Warning: No valid pairs in cascade {cascade_id}, full line: {line.strip()}, skipped")
                except ValueError:
                    print(f"Warning: Invalid cascade ID or line format, skipping: {line.strip()}")
                    continue
    except FileNotFoundError:
        print(f"Error: File {file_path} not found")
        return []
    return cascades

def aggregate_time_series(cascades, bin_size=3600, max_time=None):
    """Aggregate timestamps into a global time series using relative time"""
    all_timestamps = []
    for cascade in cascades:
        timestamps = [t for _, t in cascade['nodes'] if t is not None]
        all_timestamps.extend(timestamps)

    if not all_timestamps:
        return np.array([]), np.array([]), []

    # Convert to relative time (seconds) based on earliest timestamp
    min_time = min(all_timestamps)
    relative_timestamps = [t - min_time for t in all_timestamps]

    if max_time is None:
        max_time = max(relative_timestamps)

    bins = np.arange(0, max_time + bin_size, bin_size)
    counts, bin_edges = np.histogram(relative_timestamps, bins=bins)
    return counts, bin_edges[:-1], relative_timestamps

def fourier_analysis(counts, bin_size, sample_rate=1.0):
    """Perform Fourier transform on the global time series"""
    N = len(counts)
    if N <= 1:
        return None, None, None

    # Perform FFT
    yf = fft(counts)
    xf = fftfreq(N, 1 / sample_rate)
    amplitudes = np.abs(yf) / N

    # Separate low and high frequency components
    freq_cutoff = 0.25 / bin_size
    low_freq_mask = np.abs(xf) <= freq_cutoff
    high_freq_mask = np.abs(xf) > freq_cutoff

    yf_low = np.zeros_like(yf)
    yf_high = np.zeros_like(yf)
    yf_low[low_freq_mask] = yf[low_freq_mask]
    yf_high[high_freq_mask] = yf[high_freq_mask]

    low_time_series = ifft(yf_low).real
    high_time_series = ifft(yf_high).real

    return low_time_series, high_time_series, amplitudes

def plot_dataset_analysis(data1, data2):
    """Plot retweet patterns for two datasets, arranged vertically"""
    counts1, bin_edges1, low_time_series1, high_time_series1, dataset1_name = data1
    counts2, bin_edges2, low_time_series2, high_time_series2, dataset2_name = data2

    plt.figure(figsize=(15, 10))

    # Subplot 1: Retweet Patterns for Dataset 1
    if low_time_series1 is not None:
        plt.subplot(2, 1, 1)
        time_points1 = bin_edges1
        plt.plot(time_points1, low_time_series1, label='Low Frequency (Long-term Effect)', color='green')
        plt.plot(time_points1, high_time_series1, label='High Frequency (Short-term Effect)', color='red')
        plt.title(f'Retweet Patterns - {dataset1_name}')
        plt.xlabel('Time (seconds)')
        plt.ylabel('Reconstructed Signal')
        plt.legend()
        plt.grid(True, alpha=0.3)

    # Subplot 2: Retweet Patterns for Dataset 2
    if low_time_series2 is not None:
        plt.subplot(2, 1, 2)
        time_points2 = bin_edges2
        plt.plot(time_points2, low_time_series2, label='Low Frequency (Long-term Effect)', color='green')
        plt.plot(time_points2, high_time_series2, label='High Frequency (Short-term Effect)', color='red')
        plt.title(f'Retweet Patterns - {dataset2_name}')
        plt.xlabel('Time (seconds)')
        plt.ylabel('Reconstructed Signal')
        plt.legend()
        plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('dataset_retweet_patterns.png')
    plt.close()

def main():
    # Parameters
    bin_size = 3600  # Time bin size (1 hour, in seconds)
    sample_rate = 1.0 / bin_size

    # Parse two datasets
    cascades1 = parse_cascades('./data/twitter/cascades.txt')
    cascades2 = parse_cascades('./data/douban/cascades.txt')

    if not cascades1 or not cascades2:
        print("One or both datasets have no valid cascade data to analyze.")
        return

    # Aggregate time series for both datasets
    counts1, bin_edges1, relative_timestamps1 = aggregate_time_series(cascades1, bin_size)
    counts2, bin_edges2, relative_timestamps2 = aggregate_time_series(cascades2, bin_size)

    if len(counts1) == 0 or len(counts2) == 0:
        print("One or both datasets have no valid timestamp data to analyze.")
        return

    # Fourier analysis for both datasets
    low_time_series1, high_time_series1, amplitudes1 = fourier_analysis(counts1, bin_size, sample_rate)
    low_time_series2, high_time_series2, amplitudes2 = fourier_analysis(counts2, bin_size, sample_rate)

    # Plot results
    if low_time_series1 is not None and low_time_series2 is not None:
        data1 = (counts1, bin_edges1, low_time_series1, high_time_series1, "Twitter Dataset")
        data2 = (counts2, bin_edges2, low_time_series2, high_time_series2, "Douban Dataset")
        plot_dataset_analysis(data1, data2)
        print("Retweet patterns for both datasets saved as 'dataset_retweet_patterns.png'")
    else:
        print("No valid data to plot for one or both datasets.")

if __name__ == "__main__":
    main()