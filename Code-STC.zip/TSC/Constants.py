PAD = 0
EOS = 1

step_split = 8
n_heads = 14
